#!/bin/bash
# Simple Interest Calculator
# Formula: (Principal * Rate * Time) / 100

echo "Enter Principal:"
read p
echo "Enter Rate:"
read r
echo "Enter Time:"
read t
si=$(( (p * r * t) / 100 ))
echo "Simple Interest is: $si"
